import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRipple,
} from "mdb-react-ui-kit";
import { useSelector } from "react-redux";

function App() {
  const { filteredItems } = useSelector((state) => state.products);
  return (
    <MDBContainer fluid className="h-10 text-center">
      <MDBRow>
        {filteredItems.map((product) => (
          <MDBCol md="12" lg="3" className="mb-2">
            <MDBCard>
              <MDBRipple
                rippleColor="light"
                rippleTag="div"
                className="bg-image rounded hover-zoom"
              >
                <MDBCardImage src={product.image} className="w-50" />

                <div className="mask">
                  <div className="d-flex justify-content-start align-items-end h-100">
                    <h5>
                      <span className="badge bg-primary ms-2">New</span>
                    </h5>
                  </div>
                </div>
                <div className="hover-overlay">
                  <div
                    className="mask"
                    style={{ backgroundColor: "rgba(251, 251, 251, 0.15)" }}
                  ></div>
                </div>
              </MDBRipple>
              <MDBCardBody>
                <p>{product.category}</p>

                <h6 className="mb-3">${product.price}</h6>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        ))}
      </MDBRow>
    </MDBContainer>
  );
}

export default App;
